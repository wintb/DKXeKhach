package tien.dinh.navigationview.EventForTabHost.DateTimeFormat;

import android.content.Context;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by VuVanThang on 3/17/2016.
 */
public class CompareDateTime {

    public void comparedatetime(int dates, int months, int years,Context context){

        String datetimdselected = years+"-"+months+"-"+dates;

        try {

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date strDate = dateFormat.parse(datetimdselected);

            if (System.currentTimeMillis() <= strDate.getTime()){
                Toast.makeText(context,"Ngày đi phải lớn hơn ngày hiện tại",Toast.LENGTH_SHORT).show();

            }
            else if (System.currentTimeMillis() > strDate.getTime()){

                int a = months +1;
                Toast.makeText(context, "Selected Date is\n\n"
                                + years + "-" + a + "-" + dates,
                        Toast.LENGTH_SHORT).show();

            }

        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
