package tien.dinh.navigationview.EventForTabHost.Fragment_OneWay;

/**
 * Created by VuVanThang on 4/17/2016.
 */
public class Object_ListTrip {
    private String MaTai;
    private String GioDi;
    private String GioDen;
    private String LoTrinh;
    private String GiaVe;

    public String getGiaVe() {
        return GiaVe;
    }

    public void setGiaVe(String giaVe) {
        GiaVe = giaVe;
    }

    public String getGioDen() {
        return GioDen;
    }

    public void setGioDen(String gioDen) {
        GioDen = gioDen;
    }

    public String getGioDi() {
        return GioDi;
    }

    public void setGioDi(String gioDi) {
        GioDi = gioDi;
    }

    public String getLoTrinh() {
        return LoTrinh;
    }

    public void setLoTrinh(String loTrinh) {
        LoTrinh = loTrinh;
    }

    public String getMaTai() {
        return MaTai;
    }

    public void setMaTai(String maTai) {
        MaTai = maTai;
    }
}
