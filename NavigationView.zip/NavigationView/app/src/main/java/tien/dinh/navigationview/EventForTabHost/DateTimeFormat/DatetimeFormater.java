package tien.dinh.navigationview.EventForTabHost.DateTimeFormat;

import android.widget.TextView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by VuVanThang on 3/17/2016.
 */
public class DatetimeFormater {

    public void datetimecurrent(TextView textView){

            DateFormat dateFormat = new SimpleDateFormat("yyy-MM-dd");
            Date date = new Date();
            textView.setText(dateFormat.format(date));

    }

    public void FormatDateTime(String datetime,TextView textView){
        SimpleDateFormat format = new SimpleDateFormat("yyy-MM-dd");
        try {
            Date date = format.parse(datetime);
            textView.setText(format.format(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

}
