package tien.dinh.navigationview.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import tien.dinh.navigationview.Json_Object.Object_Chuyen;
import tien.dinh.navigationview.R;

/**
 * Created by VuVanThang on 5/11/2016.
 */
public class CustomAdapterOneTrip extends BaseAdapter {
    private List<Object_Chuyen> object_chuyenList;
    private Context context;
    private LayoutInflater layoutInflater;


    public CustomAdapterOneTrip(Context context, List<Object_Chuyen> object_chuyenList) {
        this.context = context;
        this.object_chuyenList = object_chuyenList;
    }

    @Override
    public int getCount() {
        return object_chuyenList.size();
    }

    @Override
    public Object getItem(int position) {
        return object_chuyenList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.tabhost_oneway_listtrip_listitem,parent,false);

        Object_Chuyen object_chuyen = (Object_Chuyen) getItem(position);
        TextView txtTai = (TextView) view.findViewById(R.id.txtTai);
        TextView txtGioDi = (TextView) view.findViewById(R.id.txtGioDi);
        TextView txtGioDen = (TextView) view.findViewById(R.id.txtGioDen);
        TextView txtGiaVe = (TextView) view.findViewById(R.id.txtGiaVe);
        TextView txtChon = (TextView) view.findViewById(R.id.txtChon);

        txtTai.setText(object_chuyen.getMaTai());
        txtGioDi.setText(object_chuyen.getGioDi());
        txtGioDen.setText(object_chuyen.getGioDen());
        txtGiaVe.setText(object_chuyen.getGiaVe());

        txtChon.setText(">");
        return view;
    }
}
